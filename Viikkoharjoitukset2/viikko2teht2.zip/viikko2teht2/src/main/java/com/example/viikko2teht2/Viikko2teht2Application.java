package com.example.viikko2teht2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Viikko2teht2Application {

	public static void main(String[] args) {
		SpringApplication.run(Viikko2teht2Application.class, args);
	}

}
